#ifndef GAME_ENUM_H
#define GAME_ENUM_H
/*
this enumerations helps us understand which game we will initialze(while loading/choosing game).
*/
enum whichGame {
	TTC=1,
	REVERSI=2,
	CONNECT4=3
};
typedef enum whichGame whichGame;

#endif