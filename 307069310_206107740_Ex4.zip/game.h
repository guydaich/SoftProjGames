#ifndef GAME_H
#define GAME_H

#include "windowsDrawing.h"

int SDL_Init(Uint32 flags);
int get_default_ui_tree();

#endif